#include <stdio.h>
#include <string.h>
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_system.h"
#include "esp32/aes.h"

void get_random(char * output,int number){
    for(int i = 0; i<number ;i++){
        char a = esp_random() % 26 + 97;
        output[i] = a;
    }
}

void checkmode_gpio_setup(){
    gpio_config_t io_conf;
    io_conf.pin_bit_mask = ((1ULL<<23) );
    io_conf.mode = GPIO_MODE_INPUT_OUTPUT;
    io_conf.intr_type = GPIO_INTR_POSEDGE;
    gpio_config(&io_conf);
}

int check(){
    gpio_set_level(23,1);
    vTaskDelay(1000 / portTICK_RATE_MS);
    return gpio_get_level(23) ? 0 : 1 ;
}