#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "hardware.c"
#include "bluetooth.c"
#include "network.c"
#include "mqtt.c"

#include "connect.c"
#include "mode.c"


void app_main(void)
{   
    // init
    nvs_init();
    checkmode_gpio_setup();
    hardware_gpio_setup();
    hardware_uart_setup();

    if(check()){

        printf("[+] now task : hardware, bluetooh, network\n");

        xTaskCreate(hardware, "flag{you_will_never_kown_this_flag}", 2048, NULL, 10, NULL);

        // bluetooth
        bt_app_gap_start_up();
        xTaskCreate(bt_loop, "bt_loop", 2048, NULL, 10, NULL);
        
        // network
        network_init();
        xTaskCreate(network_tcp, "network_tcp", 2048, NULL, 10, NULL);
        xTaskCreate(network_http, "network_http", 2048, NULL, 10, NULL);
        xTaskCreate(network_wifi, "network_wifi", 2048, NULL, 10, NULL);

    }else{

        printf("[+] now task : MQTT\n");

        // MQTT
        connect_wifi("THUCTFIOT","12345678");
        mqtt_app_start("mqtt://mqtt.esp32ctf.xyz");
    }
}